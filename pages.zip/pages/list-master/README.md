# List Master

The List Master Page shows the details of instances of `Item`, and will most commonly be navigated to from `ListMasterPage`.
