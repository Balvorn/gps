import { Component } from '@angular/core';
import { IonicPage, NavController } from 'ionic-angular';
import {ListMasterPage} from "../list-master/list-master";

@IonicPage()
@Component({
  selector: 'page-content',
  templateUrl: 'content.html'
})
export class ContentPage {

  constructor(public navCtrl: NavController) { }

  telecharge(){
        this.navCtrl.setRoot(ListMasterPage);
    }
}

